﻿Public Class ArticleFilter
    Public SearchType As Integer
    Public SearchValue As String
    Public Sommeil As Boolean
    Public NoEmpVide As Boolean
    Public SuiviStock As Boolean
    Public StockPositif As Boolean
End Class
