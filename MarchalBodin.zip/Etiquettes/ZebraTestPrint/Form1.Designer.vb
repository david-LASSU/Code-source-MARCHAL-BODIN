﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.refMag = New System.Windows.Forms.TextBox()
        Me.designation = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.colisage = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.emplacement = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.refFourn = New System.Windows.Forms.TextBox()
        Me.prix = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.statusBar = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.gencodeFourn = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.gencodeMag = New System.Windows.Forms.TextBox()
        Me.conditionnement = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(12, 62)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(427, 543)
        Me.TextBox1.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1160, 410)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Go"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(893, 91)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "{1} Ref Mag"
        '
        'refMag
        '
        Me.refMag.Location = New System.Drawing.Point(1002, 88)
        Me.refMag.Name = "refMag"
        Me.refMag.Size = New System.Drawing.Size(100, 20)
        Me.refMag.TabIndex = 3
        Me.refMag.Text = "001-0008/BTX"
        '
        'designation
        '
        Me.designation.Location = New System.Drawing.Point(1002, 62)
        Me.designation.Name = "designation"
        Me.designation.Size = New System.Drawing.Size(368, 20)
        Me.designation.TabIndex = 4
        Me.designation.Text = "MESURE POWERLOCK 3M AVEC DESIGNATION SUR DEUX LIGNES"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(893, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "{0} Désignation"
        '
        'colisage
        '
        Me.colisage.Location = New System.Drawing.Point(1002, 114)
        Me.colisage.Name = "colisage"
        Me.colisage.Size = New System.Drawing.Size(100, 20)
        Me.colisage.TabIndex = 6
        Me.colisage.Text = "100"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(893, 117)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(64, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "{2} Colisage"
        '
        'emplacement
        '
        Me.emplacement.Location = New System.Drawing.Point(1002, 140)
        Me.emplacement.Name = "emplacement"
        Me.emplacement.Size = New System.Drawing.Size(100, 20)
        Me.emplacement.TabIndex = 8
        Me.emplacement.Text = "B10 E10 R10 N10"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(893, 143)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(88, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "{3} Emplacement"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(893, 170)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "{4} Ref Fourn"
        '
        'refFourn
        '
        Me.refFourn.Location = New System.Drawing.Point(1002, 167)
        Me.refFourn.Name = "refFourn"
        Me.refFourn.Size = New System.Drawing.Size(100, 20)
        Me.refFourn.TabIndex = 11
        Me.refFourn.Text = "0-33-2389999999F"
        '
        'prix
        '
        Me.prix.Location = New System.Drawing.Point(1002, 222)
        Me.prix.Name = "prix"
        Me.prix.Size = New System.Drawing.Size(100, 20)
        Me.prix.TabIndex = 12
        Me.prix.Text = "1300,10"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(893, 227)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(65, 13)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "{6} Prix TTC"
        '
        'statusBar
        '
        Me.statusBar.BackColor = System.Drawing.Color.Red
        Me.statusBar.Dock = System.Windows.Forms.DockStyle.Top
        Me.statusBar.Location = New System.Drawing.Point(0, 0)
        Me.statusBar.Name = "statusBar"
        Me.statusBar.Padding = New System.Windows.Forms.Padding(5)
        Me.statusBar.Size = New System.Drawing.Size(1418, 27)
        Me.statusBar.TabIndex = 14
        Me.statusBar.Text = "Imprimante non connectée"
        Me.statusBar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(893, 196)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(98, 13)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "{5} Gencode Fourn"
        '
        'gencodeFourn
        '
        Me.gencodeFourn.Location = New System.Drawing.Point(1002, 196)
        Me.gencodeFourn.Name = "gencodeFourn"
        Me.gencodeFourn.Size = New System.Drawing.Size(100, 20)
        Me.gencodeFourn.TabIndex = 16
        Me.gencodeFourn.Text = "3700092234822"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(460, 62)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(427, 543)
        Me.TextBox2.TabIndex = 17
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(1009, 410)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 18
        Me.Button2.Text = "Preview"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(197, 43)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(55, 13)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "ZPL Code"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(636, 43)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(75, 13)
        Me.Label9.TabIndex = 20
        Me.Label9.Text = "String Preview"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(893, 254)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(92, 13)
        Me.Label10.TabIndex = 21
        Me.Label10.Text = "{7} Gencode Mag"
        '
        'gencodeMag
        '
        Me.gencodeMag.Location = New System.Drawing.Point(1002, 251)
        Me.gencodeMag.Name = "gencodeMag"
        Me.gencodeMag.Size = New System.Drawing.Size(100, 20)
        Me.gencodeMag.TabIndex = 22
        Me.gencodeMag.Text = "8436021943552"
        '
        'conditionnement
        '
        Me.conditionnement.Location = New System.Drawing.Point(1002, 277)
        Me.conditionnement.Name = "conditionnement"
        Me.conditionnement.Size = New System.Drawing.Size(100, 20)
        Me.conditionnement.TabIndex = 24
        Me.conditionnement.Text = "** Rouleau 100 m **"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(893, 280)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(103, 13)
        Me.Label11.TabIndex = 23
        Me.Label11.Text = "{8} Conditionnement"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1418, 617)
        Me.Controls.Add(Me.conditionnement)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.gencodeMag)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.gencodeFourn)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.statusBar)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.prix)
        Me.Controls.Add(Me.refFourn)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.emplacement)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.colisage)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.designation)
        Me.Controls.Add(Me.refMag)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(false)
        Me.PerformLayout

End Sub
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents refMag As System.Windows.Forms.TextBox
    Friend WithEvents designation As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents colisage As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents emplacement As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents refFourn As System.Windows.Forms.TextBox
    Friend WithEvents prix As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents statusBar As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents gencodeFourn As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents gencodeMag As TextBox
    Friend WithEvents conditionnement As TextBox
    Friend WithEvents Label11 As Label
End Class
