﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ListeCommandes.Model
{
    public enum CommandeStatut
    {
        Saisi = 0,
        Confirme = 1,
        Accepte = 2
    }
}
