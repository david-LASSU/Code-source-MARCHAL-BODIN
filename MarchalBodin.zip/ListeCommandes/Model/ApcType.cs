﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ListeCommandes.Model
{
    public enum ApcType
    {
        DemandeDePrixClient = 0,
        DemandeDePrixStock = 1,
        Reservation = 2,
        Stock = 3,
    }
}
