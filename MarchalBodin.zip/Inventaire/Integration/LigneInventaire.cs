﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integration
{
    class LigneInventaire
    {
        public string emplacement;
        public string reference;
        public double quantite;
        public double prixAch;
        public double total;
        public string designation;
        public DateTime date;
        public string codeBarre;
    }
}
