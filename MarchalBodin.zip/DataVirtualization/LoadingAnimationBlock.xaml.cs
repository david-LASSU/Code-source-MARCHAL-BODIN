﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace DevZest.Windows.DataVirtualization
{
    /// <summary>
    /// Interaction logic for LoadingAnimationBlock.xaml
    /// </summary>
    public partial class LoadingAnimationBlock : UserControl
    {
        public LoadingAnimationBlock()
        {
            InitializeComponent();
        }
    }
}
