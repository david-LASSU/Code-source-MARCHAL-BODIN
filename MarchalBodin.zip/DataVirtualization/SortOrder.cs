﻿using System;

namespace DevZest.Windows.DataVirtualization
{
    public enum SortOrder
    {
        None,
        Ascending,
        Descending
    }
}
