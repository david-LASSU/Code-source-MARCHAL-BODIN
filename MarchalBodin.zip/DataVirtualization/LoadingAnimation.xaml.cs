﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace DevZest.Windows.DataVirtualization
{
    /// <summary>
    /// Interaction logic for LoadingAnimation.xaml
    /// </summary>
    public partial class LoadingAnimation : UserControl
    {
        public LoadingAnimation()
        {
            InitializeComponent();
        }
    }
}
