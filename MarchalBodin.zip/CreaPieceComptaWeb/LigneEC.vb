﻿Public Class LigneEC
    Public Property trId As Integer
    Public Property opeType As String
    Public Property brutAmount As Double
    Public Property remDate As Date
    Public Property remId As Integer
    Public Property netAmount As Double
    Public Property comAmount As Double
End Class
