namespace OnScreenKeyboardControl.Keyboard
{
	public enum OnScreenKeyType { Text, Modifier, Toggle }
}