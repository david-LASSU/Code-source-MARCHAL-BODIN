namespace OnScreenKeyboardControl.Keyboard
{
	public enum OnScreenKeyModifierType { None, Shift, NumLock, Special }
}